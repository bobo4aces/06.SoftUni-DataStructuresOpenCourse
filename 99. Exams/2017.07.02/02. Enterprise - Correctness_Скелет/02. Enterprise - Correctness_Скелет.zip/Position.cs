﻿public enum Position
{
    Developer, Manager, Hr, TeamLead, Owner
}
