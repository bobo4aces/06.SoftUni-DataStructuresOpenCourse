﻿namespace _04.LinkedStack
{
    public class Program
    {
        public static void Main()
        {
        }
    }
}
