﻿using System;
using System.Linq;

public class ArrayStack<T>
{
    public const int InitialCapacity = 16;

    private T[] _elements;

    public int Count { get; set; }

    public ArrayStack(int capacity = InitialCapacity)
    {
        _elements = new T[capacity];
    }

    public void Push(T element)
    {
        if (_elements.Length == Count)
        {
            Grow();
        }

        _elements[Count] = element;
        Count++;
    }

    public T Pop()
    {
        if (Count == 0)
        {
            throw new InvalidOperationException("There are no elements to pop.");
        }

        Count--;
        return _elements[Count];
    }

    private void Grow()
    {
        T[] newArray = new T[_elements.Length * 2];
        Array.Copy(_elements, newArray, _elements.Length);
        _elements = newArray;
    }

    public T[] ToArray()
    {
        T[] array = new T[Count];
        for (int i = Count - 1; i >= 0; i--)
        {
            array[i] = _elements[Count - i - 1];
        }
        return array;
    }

}
