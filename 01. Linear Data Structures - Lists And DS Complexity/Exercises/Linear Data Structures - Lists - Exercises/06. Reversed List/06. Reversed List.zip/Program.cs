﻿using System;

namespace _06._Reversed_List
{
    public class Program
    {
        public static void Main()
        {
        }
    }
}
