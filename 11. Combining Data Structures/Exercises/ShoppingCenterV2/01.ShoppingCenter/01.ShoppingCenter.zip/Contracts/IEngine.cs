﻿public interface IEngine
{
    void Run();

    string ProcessCommand(string input); 
}